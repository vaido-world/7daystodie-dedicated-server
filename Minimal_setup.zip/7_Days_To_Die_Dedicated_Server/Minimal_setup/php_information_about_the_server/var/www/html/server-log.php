<!-- /var/log/apache2/error.log 

			<?php echo shell_exec("sudo cat /home/steam/.local/share/Steam/steamcmd/7dtd/7DaysToDieServer_Data/output_log__2024-02-12__14-37-31.txt"); ?>
			<?php echo shell_exec("ls"); ?>
			<?php echo shell_exec("whoami"); ?>
			<?php echo shell_exec("ls /home/steam/.local/share/Steam/steamcmd/7dtd/7DaysToDieServer_Data/"); ?>
			<?php echo shell_exec("ls /home/steam/"); ?>
			<?php echo shell_exec("ls /home/"); ?>
			<?php echo exec('whoami'); ?>
							<?php echo shell_exec("sudo ls /home/steam/.local/share/Steam/steamcmd/7dtd/7DaysToDieServer_Data"); ?>



-->

<nav>
		<pre id="test" style="background: white; border: black solid 1px; width: fit-content; tab-size: 0; padding-right: 12px; padding-left: 9px;"><strong>Currently running 7dtd Screen Session on the server</strong>
			<!--<?php echo shell_exec("ls -rt /home/steam/.local/share/Steam/steamcmd/7dtd/7DaysToDieServer_Data/*.txt "); ?>
				<?php echo shell_exec("sudo cat /home/steam/.local/share/Steam/steamcmd/7dtd/7DaysToDieServer_Data/output_log__2024-02-12__14-37-31.txt"); ?>
				
				<?php $output = shell_exec('sudo ls /home/steam/.local/share/Steam/steamcmd/7dtd/7DaysToDieServer_Data'); echo $output; ?>
				$output = shell_exec('sudo ls /home/steam/.local/share/Steam/steamcmd/7dtd/7DaysToDieServer_Data 2>&1'); echo $output;

				-->
				
				<?php 
					$output = shell_exec('sudo /bin/sh test.bash '); echo $output;
				
				?>
									

		</pre>
</nav>


 <script>

 setTimeout(function(){
 window.scrollTo(0,document.body.scrollHeight);

}, 100);
 
 

 </script>