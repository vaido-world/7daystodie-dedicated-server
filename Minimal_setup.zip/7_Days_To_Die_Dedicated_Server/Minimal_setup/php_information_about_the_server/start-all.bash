#!/bin/bash
#ls "[0-9]*.*"
for file in [0-9]*.*; do
    echo "$file"
	bash "./$file"
done
