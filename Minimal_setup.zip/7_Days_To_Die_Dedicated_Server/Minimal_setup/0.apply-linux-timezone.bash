#!/bin/bash
timedatectl set-timezone Europe/Vilnius