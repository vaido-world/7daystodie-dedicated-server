<?php
// sudo chown -R www-data:www-data /var/www

/* find folders owned by www-data
    find / -group www-data
*/

// php code for logging error into a given file
  
// error message to be logged
$error_message = "This is an error message!\n";
  
// path of the log file where errors need to be logged
$log_file = "/var/cache/apache2/mod_cache_disk/my-errors.log";       
  
// logging error message to given log file
error_log($error_message, 3, $log_file);

error_log($error_message = "Logging HTTP_REFERER", 3, $log_file = "/var/cache/apache2/mod_cache_disk/my-errors.log");	
  

//error_log("test " . $_SERVER['HTTP_REFERER'], 0);
if(isset($_SERVER['HTTP_REFERER'])) {
    echo $_SERVER['HTTP_REFERER'];



}

if ( $_POST['payload'] ) {
shell_exec("bash /var/www/html/script.bash");

}

?>Github Handle Script loaded without errors.
