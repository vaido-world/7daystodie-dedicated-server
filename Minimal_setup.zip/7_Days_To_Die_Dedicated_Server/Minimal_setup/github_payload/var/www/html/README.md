To test if payload has been sent, look at the logs of apache.

\var\log\apache2\error.log