echo Configuring 7 Days To Die Server by Changing 7dtd/serverconfig.xml file
su --preserve-env "steam" <<- 'EOF'
    cd "/home/steam"
    HOME="/home/steam"
# Change Default 7DTD Server Region
  xmlstarlet edit --inplace \
    --update "//property[@name='Region']/@value" \
    --value "Europe" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# Change Default 7DTD First-time-join Server Map Downloading speed
  xmlstarlet edit --inplace \
    --update "//property[@name='ServerMaxWorldTransferSpeedKiBs']/@value" \
    --value "1500" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# Change Default 7DTD Game Server Name
  xmlstarlet edit --inplace \
    --update "//property[@name='ServerName']/@value" \
    --value "🌓 7 Days To Die Vanilla Public Server" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# Add Website to the Description of the Game Server in the Lobby
  xmlstarlet edit --inplace \
    --update "//property[@name='ServerWebsiteURL']/@value" \
    --value "https://steamcommunity.com/chat/invite/hEKkGncq" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# Add ServerLoginConfirmationText to the Game Server 
  xmlstarlet edit --inplace \
    --update "//property[@name='ServerLoginConfirmationText']/@value" \
    --value "7 Days To Die Vanilla Public Server. All default normal settings. [-]\n ServerName: 7 Days To Die Vanilla Public Server [-]\n ServerIP: 185.80.128.223 [-] ServerPort: 26900 \n\n Server restarts are rare: on minor changes and updates only. [-]\n\n Difficulty: Adventurer (Default) [-]\n XP Multiplier: 100% (Default) [-]\n Loot Abundance: 100% (Default) [-]\n Loot Respawn time: 5 Days [-]\n\n One in-game day is equal to two hours. \n\n [FFD700]New:[-] Blood Moon happens at range of 6, 7, 8 day instead of at 7th day everytime. \n [FFD700]New:[-] All in-game vehicles are now faster and stronger. \n [ff5700]New-testing:[-] Biome spawning system: more zombies and animals. Pine Forest spawning rework for multiplayer experience. \n [ff5700]New-testing:[-] Spike traps are now way more durable. \n [FFD700]New:[-] All vehicles have seats, even gyrocopter. Bicycle can handle two people. The 4x4 truck have 4 seats. \n [FFD700]New:[-] Migration to a new hosting that have faster CPU, RAM, SSD and better network connection. \n [FFD700]New:[-] Restarting system with notice and wait time. Ability to download server map. Ability to check the server's performance.

" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# Change Default 7DTD Game Server Description
  xmlstarlet edit --inplace \
    --update "//property[@name='ServerDescription']/@value" \
    --value "\n Basic Vanilla Public Server. \n Longterm and reliable with minimal modlets. \n One in-game day is equal to two hours. \n\n [d6d6d6]Join the Steam Group:[-]" "/home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml"
# Change the Default 8 Player slot to 16
  xmlstarlet edit --inplace \
    --update "//property[@name='ServerMaxPlayerCount']/@value" \
    --value "16" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# The amount of Experience the Players get after Killing a zombie, Looting and other activities
  xmlstarlet edit --inplace \
    --update "//property[@name='XPMultiplier']/@value" \
    --value "100" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# Drop on Death Backpack only
  xmlstarlet edit --inplace \
    --update "//property[@name='DropOnDeath']/@value" \
    --value "3" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# The amount of Loot that Players will find in the World Containers
  xmlstarlet edit --inplace \
    --update "//property[@name='LootAbundance']/@value" \
    --value "100" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# Respawn Loot twice as often
  xmlstarlet edit --inplace \
    --update "//property[@name='LootRespawnDays']/@value" \
    --value "5" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# Let the administrator to join the server even if the server is full
  xmlstarlet edit --inplace \
    --update "//property[@name='ServerAdminSlots']/@value" \
    --value "1" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# Make AirDrop default
  xmlstarlet edit --inplace \
    --update "//property[@name='AirDropFrequency']/@value" \
    --value "72" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# Make AirDrop not Visible on Map (default)
  xmlstarlet edit --inplace \
    --update "//property[@name='AirDropMarker']/@value" \
    --value "false" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# Change the 7 Days To Die Dedicated Server PlayerKillingMode to default
  xmlstarlet edit --inplace \
    --update "//property[@name='PlayerKillingMode']/@value" \
    --value "0" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml  
# Enable Navezgane for the Server
  xmlstarlet edit --inplace \
    --update "//property[@name='GameWorld']/@value" \
    --value "Navezgane" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# Set default Random World Generator
  xmlstarlet edit --inplace \
    --update "//property[@name='asdfx']/@value" \
    --value "1354778" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# Set the map size for the Random World Generator
# Has to be between 2048 and 16384
  xmlstarlet edit --inplace \
    --update "//property[@name='WorldGenSize']/@value" \
    --value "4096" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# Set the Map Name for the Random World Generator
  xmlstarlet edit --inplace \
    --update "//property[@name='GameName']/@value" \
    --value "MyGame" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# Disable Control Panel for Direct Control of the GameServer
  xmlstarlet edit --inplace \
    --update "//property[@name='ControlPanelEnabled']/@value" \
    --value "false" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# Difficulty
  xmlstarlet edit --inplace \
    --update "//property[@name='GameDifficulty']/@value" \
    --value "2" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# Zombie block damage
  xmlstarlet edit --inplace \
    --update "//property[@name='BlockDamageAI']/@value" \
    --value "75" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# PlayerSafeZoneLevel
  xmlstarlet edit --inplace \
    --update "//property[@name='PlayerSafeZoneLevel']/@value" \
    --value "5" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# DayNightLength
  xmlstarlet edit --inplace \
    --update "//property[@name='DayNightLength']/@value" \
    --value "120" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# MaxSpawnedZombies
  xmlstarlet edit --inplace \
    --update "//property[@name='MaxSpawnedZombies']/@value" \
    --value "164" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# DayNightLength
  xmlstarlet edit --inplace \
    --update "//property[@name='MaxSpawnedAnimals']/@value" \
    --value "150" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
	
# BloodMoonFrequency
  xmlstarlet edit --inplace \
    --update "//property[@name='BloodMoonFrequency']/@value" \
    --value "7" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# BloodMoonRange
  xmlstarlet edit --inplace \
    --update "//property[@name='BloodMoonRange']/@value" \
    --value "2" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# LandClaimCount
  xmlstarlet edit --inplace \
    --update "//property[@name='LandClaimCount']/@value" \
    --value "2" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# LandClaimOnlineDurabilityModifier
  xmlstarlet edit --inplace \
    --update "//property[@name='LandClaimOnlineDurabilityModifier']/@value" \
    --value "16" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# LandClaimOfflineDurabilityModifier
  xmlstarlet edit --inplace \
    --update "//property[@name='LandClaimOfflineDurabilityModifier']/@value" \
    --value "16" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml
# EnableMapRendering
  xmlstarlet edit --inplace \
    --update "//property[@name='EnableMapRendering']/@value" \
    --value "true" /home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml

EOF

echo Setttings loaded.
echo Restarting 7 Days to Die server.
bash "./announce_server_update/server_restart.bash"
