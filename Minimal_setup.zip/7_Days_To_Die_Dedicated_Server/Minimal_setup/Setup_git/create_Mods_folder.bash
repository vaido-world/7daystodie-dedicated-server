#!/bin/bash
mkdir "/home/steam/.steam/steamcmd/7dtd/Mods"
[ ! -f /home/steam/.steam/steamcmd/7dtd/Mods/README.md ] && touch /home/steam/.steam/steamcmd/7dtd/Mods/README.md