apt-get update
apt-get install zip unzip -y
mkdir "/var/www/html/7dtd_map_autobackup_cronjob";
sudo bash -c '
cat <<"EOF" > /etc/cron.d/7dtd-map-backups
0 */6 * * * root /usr/bin/zip -r /var/www/html/7dtd_map_autobackup_cronjob/7dtd_map_$(date "+\%Y-\%m-\%d_\%H-\%M_UTC").zip /home/steam/.local/share/Steam/steamcmd/7dtd/Saves/
EOF'