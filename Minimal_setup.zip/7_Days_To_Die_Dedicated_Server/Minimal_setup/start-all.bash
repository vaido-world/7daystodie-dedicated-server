#!/bin/bash

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

#ls "[0-9]*.*"
for file in "$SCRIPT_DIR"/[0-9]*.*; do
    echo "$file"
	bash "$file"
done


bash "./php_information_about_the_server/start-all.bash"

