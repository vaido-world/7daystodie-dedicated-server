# Not implemented.
# ls -laR /var/run/screen/
# screen -XS 7DaysToDie_GameServer quit