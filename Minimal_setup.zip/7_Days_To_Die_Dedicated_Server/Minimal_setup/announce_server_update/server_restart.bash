# trap ctrl-c and call ctrl_c()
trap ctrl_c INT

function ctrl_c() {

        echo "** Trapped CTRL-C"
		rm /var/tmp/date-for-7dtd-restart-check
		(echo 'say "[f9caa7]Restart Canceled"' )>&3
		exit
}


	exec 3<>/dev/tcp/localhost/8081
	# After connecting via Telnet, use Game Server Telnet Password to authenticate.
	echo 'hahaha' >&3 

    (echo 'say "[f9caa7]Restart will happen in 10 seconds."' )>&3
    sleep 1;
    (echo 'say "[f9caa7]Restart will happen in 9 seconds."' )>&3
    sleep 1;
    (echo 'say "[f9caa7]Restart will happen in 8 seconds."' )>&3
    sleep 1;
    (echo 'say "[f9caa7]Restart will happen in 7 seconds."' )>&3
    sleep 1;
    (echo 'say "[f9caa7]Restart will happen in 6 seconds."' )>&3
    sleep 1;
    (echo 'say "[f9caa7]Restart will happen in 5 seconds."' )>&3
    sleep 1;
    (echo 'say "[f9caa7]Restart will happen in 4 seconds."' )>&3
    sleep 1;
    (echo 'say "[f9caa7]Restart will happen in 3 seconds."' )>&3
    sleep 1;
    (echo 'say "[f9caa7]Restart will happen in 2 seconds."' )>&3
    sleep 1;
    (echo 'say "[f9caa7]Restart will happen in 1 seconds."' )>&3
    sleep 1;
    (echo 'say "[f9caa7]Restarting the server for Community update."' )>&3
    sleep 1;
    (echo 'shutdown')>&3
    sleep 5;
    screen -X -S "7DaysToDie_GameServer" quit
    sleep 2;
    
    su - steam <<-'EOF1'
    cp "/home/steam/.local/share/Steam/steamcmd/7dtd/serverconfig.xml" "/home/steam/.local/share/Steam/steamcmd/7dtd/secure_serverconfig.xml"
        xmlstarlet edit --inplace \
            --update "//property[@name='ControlPanelEnabled']/@value" \
            --value "true" /home/steam/.local/share/Steam/steamcmd/7dtd/secure_serverconfig.xml
        xmlstarlet edit --inplace \
            --update "//property[@name='ControlPanelPassword']/@value" \
            --value "hahaha" /home/steam/.local/share/Steam/steamcmd/7dtd/secure_serverconfig.xml
        xmlstarlet edit --inplace \
            --update "//property[@name='TelnetEnabled']/@value" \
            --value "true" /home/steam/.local/share/Steam/steamcmd/7dtd/secure_serverconfig.xml
        xmlstarlet edit --inplace \
            --update "//property[@name='TelnetPort']/@value" \
            --value "8081" /home/steam/.local/share/Steam/steamcmd/7dtd/secure_serverconfig.xml
        xmlstarlet edit --inplace \
            --update "//property[@name='TelnetPassword']/@value" \
            --value "hahaha" /home/steam/.local/share/Steam/steamcmd/7dtd/secure_serverconfig.xml
        screen -d -m -S "7DaysToDie_GameServer" "/home/steam/.local/share/Steam/steamcmd/7dtd/startserver.sh" "-configfile=secure_serverconfig.xml"
EOF1
