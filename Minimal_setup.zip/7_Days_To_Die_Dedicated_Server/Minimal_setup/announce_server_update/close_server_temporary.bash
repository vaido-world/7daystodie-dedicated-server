# Not implemented. Notes of implementation.

# Announce that server is closing
# Add new generated password to the server via xml
# Restart the server.

# unclose_server_remove_password
# Announce that server is opening
# Remove the server password.
# Restart the server.