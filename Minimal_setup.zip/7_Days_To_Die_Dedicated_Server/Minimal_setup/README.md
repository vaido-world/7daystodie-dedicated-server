telnet password is set on 1.ubuntu-install-steamcmd-7dtd.bash to both server settings and telnetpassword.txt
You have to modify both both server settings and telnetpassword.txt 

On server restart of announce_server_update the telnetpassword.txt is enforced using xml modification to server settings.

start-all.bash forgets to install bash "./php_information_about_the_server/start-all.bash"
Also: bash "./3.setup_gameserver_backup.bash"

The only correct way to start the server is to use restart command bash ./announce_server_update/server_restart.bash

The startserver_with_security.sh needs revision and fixing.

There is 7dtd_restart linux command for quick restart.
7dtd command for quick navigation to linux folder of 7dtd dedicated server
back command for quick navigation back to the main Dedicated Server Setup folder.

announce_server_update/announce_server_about_update.bash
The announcement restart needs ability to be canceled with some "cancel-the-10min-restart.bash"
The announcement restart currently won't happen if you turn off terminal or do other things with terminal.

