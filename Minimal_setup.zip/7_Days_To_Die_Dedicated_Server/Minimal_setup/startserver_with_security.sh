[ "$(whoami)" = "steam" ] && ( 
	cp "/home/steam/.steam/steamcmd/7dtd/serverconfig.xml" "/home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml"
	xmlstarlet edit --inplace \
		--update "//property[@name='ControlPanelEnabled']/@value" \
		--value "true" /home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml
	xmlstarlet edit --inplace \
		--update "//property[@name='ControlPanelPassword']/@value" \
		--value "hahaha" /home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml
	xmlstarlet edit --inplace \
		--update "//property[@name='TelnetEnabled']/@value" \
		--value "true" /home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml
	xmlstarlet edit --inplace \
		--update "//property[@name='TelnetPort']/@value" \
		--value "8081" /home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml
	xmlstarlet edit --inplace \
		--update "//property[@name='TelnetPassword']/@value" \
		--value "hahaha" /home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml
	screen -d -m -S "7DaysToDie_GameServer" "/home/steam/.steam/steamcmd/7dtd/startserver.sh" "-configfile=secure_serverconfig.xml"
) || (
	# https://ubuntuforums.org/archive/index.php/t-2061039.html
	echo You are trying to start the server not as a linux user named "steam"
	su --preserve-env "steam" <<- 'EOF'
		exec 3<>/dev/tcp/localhost/8081
		echo 'hahaha' >&3

		sleep 1;
		echo 'shutdown' >&3
		
		echo "multiuser on" > /home/steam/.steam/steamcmd/7dtd/multiscreen.conf
		echo "acladd root" >> /home/steam/.steam/steamcmd/7dtd/multiscreen.conf
		cd "/home/steam"
		HOME="/home/steam"
		cp "/home/steam/.steam/steamcmd/7dtd/serverconfig.xml" "/home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml"
			xmlstarlet edit --inplace \
				--update "//property[@name='ControlPanelEnabled']/@value" \
				--value "true" /home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml
			xmlstarlet edit --inplace \
				--update "//property[@name='ControlPanelPort']/@value" \
				--value "8080" /home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml
			xmlstarlet edit --inplace \
				--update "//property[@name='ControlPanelPassword']/@value" \
				--value "hahaha" /home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml
			xmlstarlet edit --inplace \
				--update "//property[@name='TelnetEnabled']/@value" \
				--value "true" /home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml
			xmlstarlet edit --inplace \
				--update "//property[@name='TelnetPort']/@value" \
				--value "8081" /home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml
			xmlstarlet edit --inplace \
				--update "//property[@name='TelnetPassword']/@value" \
				--value "hahaha" /home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml
					screen -c /home/steam/.steam/steamcmd/7dtd/multiscreen.conf -d -m -S "7DaysToDie_GameServer" "/home/steam/.steam/steamcmd/7dtd/startserver.sh" "-configfile=secure_serverconfig.xml"
	EOF
	
	screen -ls steam/

)

