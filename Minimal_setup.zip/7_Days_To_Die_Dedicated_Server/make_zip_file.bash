#!/bin/bash

if ! command -v 7z &> /dev/null
then
    echo "7zip could not be found; will be installed."
	apt install p7zip-full -y
	apt install p7zip-rar -y 

    exit 1
fi

FILE="./Minimal_setup.zip"
if test -f "$FILE"; then
    echo "$FILE exists."
	echo "removing $FILE"
	rm "$FILE"
fi

7z a "./Minimal_setup.zip" "../7_Days_To_Die_Dedicated_Server/"