#!/bin/bash
apt -y install p7zip-full p7zip-rar
7z a "./Minimal_setup.zip" "../7_Days_To_Die_Dedicated_Server/"