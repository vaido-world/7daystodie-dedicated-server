<style>
body {
	background-color: white;
	height: 5000;
	width: 5000;
}
</style>




<nav>
<pre style="background: white; border: black solid 1px; width: fit-content; tab-size: 0; padding-right: 12px; padding-left: 9px;"><strong>Currently running 7dtd Screen Session on the server</strong>
		<?php echo shell_exec("tail -5 \"$(ls -rt /home/steam/.steam/steamcmd/7dtd/7DaysToDieServer_Data/*.txt | tail -n1)\""); ?>
		</pre>
   
		<h3 id="Server Internal Resources Monitoring">Server Internal Resources Monitoring</h3>
		<pre style="background: white; border: black solid 1px; width: fit-content; tab-size: 0; padding-right: 12px; padding-left: 9px;"><strong>Current Ram Memory usage of the server</strong>
		<?php echo shell_exec("free -h"); ?>
		</pre>
		<pre style="background: white; border: black solid 1px; width: fit-content; tab-size: 0; padding-right: 12px; padding-left: 9px;"><strong>Current CPU And Memory usage of the server</strong>
		<?php echo shell_exec("top -bcn1 -w87 | head -n25"); ?>
		</pre>
		
		<pre style="background: white; border: black solid 1px; width: fit-content; tab-size: 0; padding-right: 12px; padding-left: 9px;"><strong>Currently running 7dtd Screen Session on the server</strong>
<?php echo shell_exec("sudo ls -lR /var/run/screen/S-steam"); ?>
<p align="center">
<a href="https://cutt.ly/LmDkTlN">
<img src="https://user-images.githubusercontent.com/21064622/125660938-498f1a80-22ba-404d-93e9-d5440d02bfe1.png" draggable="false"><br>
🔌 Quick Connect to the 7 Days To Die </a></br>
This will launch your 7 Days To Die game.
<p align="center">
The server's end of life is due 2023-06-28 (if without any active sponsors or community support)  
</p>

<p align="center">
<a href=""><img src="https://cache.gametracker.com/server_info/94.176.237.38:26900/banner_560x95.png?random=489986"></a><br>
</p>

</pre>



</nav>
<script>




window.addEventListener('load',function() {
    if(localStorage.getItem('scrollPosition') !== null)
       window.scrollTo(0, localStorage.getItem('scrollPosition'));
},false);

window.addEventListener('scroll',function() {
    //When scroll change, you save it on localStorage.
    localStorage.setItem('scrollPosition',window.scrollY);
},false);



setTimeout(function(){
   window.location.reload(1);
   
}, 1000);
</script>