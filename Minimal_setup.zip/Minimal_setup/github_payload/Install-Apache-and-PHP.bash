#!/bin/bash

# Prepare for installation
sudo apt-get upgrade 
sudo apt-get update 

# Install Apache2 and PHP
sudo apt-get install apache2 -y
sudo apt-get install php -y