<?php
if ( $_POST['payload'] ) {
shell_exec("bash /var/www/html/script.bash");
}

?>Github Handle Script loaded without errors.
