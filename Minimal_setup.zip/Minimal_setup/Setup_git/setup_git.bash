# Install git client and setup local repository
sudo apt install git -y
cd "/home/steam/.steam/steamcmd/7dtd/"
git init

sudo git remote add origin https://boqsc:f80ea0344265617d5db2e72313101883f408196b@github.com/vaido-world/7daystodie-live-server.git
sudo git remote set-url origin https://boqsc:f80ea0344265617d5db2e72313101883f408196b@github.com/vaido-world/7daystodie-live-server.git

# .gitignore folders and files
echo "Data/*
7DaysToDieServer_Data/*
Saves[0-9]*/*
secure_serverconfig.xml
startserver_with_security.sh
" > "/home/steam/.steam/steamcmd/7dtd/.gitignore"