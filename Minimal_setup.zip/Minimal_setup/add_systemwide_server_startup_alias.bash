#!/bin/bash

echo "alias foo='echo yes'" > /etc/profile.d/7dtd-server-aliases.sh
echo "alias 7dtd='cd /home/steam/.steam/steamcmd/7dtd'" >> /etc/profile.d/7dtd-server-aliases.sh
echo "alias 7dtd_start='bash /home/steam/.steam/steamcmd/7dtd/startserver_with_security.sh'" >> /etc/profile.d/7dtd-server-aliases.sh


# Replace/restart bash itself
# Note that this won't affect things such as the cwd or exported variables.
exec bash -l