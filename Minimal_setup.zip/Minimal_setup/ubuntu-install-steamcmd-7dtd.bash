# Configure the Ubuntu Upgrade (debconf defaults for console-setup)
  echo "console-setup   console-setup/charmap47 select  UTF-8" > "/var/tmp/encoding.conf";
  echo "console-setup   console-setup/codeset47 select  Guess optimal character set" >> "/var/tmp/encoding.conf";
  echo "keyboard-configuration   keyboard-configuration/layout select  English (US)" >> "/var/tmp/encoding.conf";
  echo "keyboard-configuration   keyboard-configuration/variant select English (US)" >> "/var/tmp/encoding.conf";
  debconf-set-selections "/var/tmp/encoding.conf";
  rm "/var/tmp/encoding.conf";
  
# Configure the Ubuntu Upgrade (merging configurations)
  apt-get update;
  apt-get --yes \
	--allow-downgrades \
	--allow-remove-essential \
	--allow-change-held-packages \
	-o Dpkg::Options::="--force-confdef" \
	-o Dpkg::Options::="--force-confnew" \
	upgrade;

# Create a new Linux User by the name "steam"
useradd -m "steam";
password="ds]fkl;]asDfk";

echo "steam:$password" | chpasswd;
chsh "steam" --shell "/bin/bash";
usermod --append \
        --groups "sudo" "steam";
		
# Fix add-apt-repository: command not found error
apt-get install software-properties-common -y

# Agree with SteamCmd [Terms of Use]
su --preserve-env "steam" <<- 'EOF'
    echo "($password)" | sudo -S echo > /dev/null
    echo steam steam/question select "I AGREE" | sudo debconf-set-selections
    echo steam steam/license note '' | sudo debconf-set-selections
EOF


# Install SteamCmd for Linux User "steam"
# SteamCmd is used to Download Game Server Files For Dedicated Servers and Update Them
su --preserve-env "steam" <<- 'EOF'
    cd "/home/steam"
    HOME="/home/steam"
    echo "($password)" | sudo -S echo > /dev/null
    sudo add-apt-repository multiverse
    sudo dpkg --add-architecture i386
    sudo apt update
    sudo apt install lib32gcc1 steamcmd -y
EOF

# Use SteamCmd to Download Dedicated Server Files for 7 Days To Die 
su --preserve-env "steam" <<- 'EOF'
    cd "/home/steam"
    HOME="/home/steam"
    echo "($password)" | sudo -S echo > /dev/null
    steamcmd +login anonymous \
	         +force_install_dir "./7dtd" \
			 +app_update 294420 \
			 +quit
EOF


# Install XML document parser for parsing and changing 7 Days To Die serverconfig.xml and other .xml files
su --preserve-env "steam" <<- 'EOF'
    cd "/home/steam"
    HOME="/home/steam"
    echo "($password)" | sudo -S echo > /dev/null
    sudo apt-get install -y xmlstarlet
EOF

# Configure 7 Days To Die Server by Changing 7dtd/serverconfig.xml file
su --preserve-env "steam" <<- 'EOF'
    cd "/home/steam"
    HOME="/home/steam"
# Change Default 7DTD Game Server Name
  xmlstarlet edit --inplace \
    --update "//property[@name='ServerName']/@value" \
    --value "[EU][PVP] 7 Days To Die Vanilla Public | XP 1000% | Loot 300%" /home/steam/.steam/steamcmd/7dtd/serverconfig.xml
# Add Website to the Description of the Game Server in the Lobby
  xmlstarlet edit --inplace \
    --update "//property[@name='ServerWebsiteURL']/@value" \
    --value "7days.vaido.world" /home/steam/.steam/steamcmd/7dtd/serverconfig.xml
# Change Default 7DTD Game Server Description
  xmlstarlet edit --inplace \
    --update "//property[@name='ServerDescription']/@value" \
    --value "[EU] 7 Days To Die 
    Vanilla Public PVP | XP 1000 | Loot 300
  The Dedicated server is based in Europe/Lithuania.
  If you can, support this server. 
  Contact the owner: vaidas.boqsc@gmail.com
  The Server is as close to the Vanilla as possible, 
  but focused on less tiring gameplay.
  No client side mods.
  Any suggestions are Welcome." "/home/steam/.steam/steamcmd/7dtd/serverconfig.xml"
# Change the Default 8 Player slot to 20
  xmlstarlet edit --inplace \
    --update "//property[@name='ServerMaxPlayerCount']/@value" \
    --value "20" /home/steam/.steam/steamcmd/7dtd/serverconfig.xml
# The amount of Experience the Players get after Killing a zombie, Looting and other activities
  xmlstarlet edit --inplace \
    --update "//property[@name='XPMultiplier']/@value" \
    --value "1000" /home/steam/.steam/steamcmd/7dtd/serverconfig.xml
# Drop on Death Backpack only
  xmlstarlet edit --inplace \
    --update "//property[@name='DropOnDeath']/@value" \
    --value "3" /home/steam/.steam/steamcmd/7dtd/serverconfig.xml
# The amount of Loot that Players will find in the World Containers
  xmlstarlet edit --inplace \
    --update "//property[@name='LootAbundance']/@value" \
    --value "300" /home/steam/.steam/steamcmd/7dtd/serverconfig.xml
# Respawn Loot twice as often
  xmlstarlet edit --inplace \
    --update "//property[@name='LootRespawnDays']/@value" \
    --value "15" /home/steam/.steam/steamcmd/7dtd/serverconfig.xml
# Let the administrator to join the server even if the server is full
  xmlstarlet edit --inplace \
    --update "//property[@name='ServerAdminSlots']/@value" \
    --value "1" /home/steam/.steam/steamcmd/7dtd/serverconfig.xml
# Make AirDrop Twice as often
  xmlstarlet edit --inplace \
    --update "//property[@name='AirDropFrequency']/@value" \
    --value "36" /home/steam/.steam/steamcmd/7dtd/serverconfig.xml
# Make AirDrop Visible on Map
  xmlstarlet edit --inplace \
    --update "//property[@name='AirDropMarker']/@value" \
    --value "true" /home/steam/.steam/steamcmd/7dtd/serverconfig.xml
# Change the Initial Incorrect 7 Days To Die Dedicated Server PlayerKillingMode
  xmlstarlet edit --inplace \
    --update "//property[@name='PlayerKillingMode']/@value" \
    --value "2" /home/steam/.steam/steamcmd/7dtd/serverconfig.xml  
# Enable Random World Generator for the Server
  xmlstarlet edit --inplace \
    --update "//property[@name='GameWorld']/@value" \
    --value "RWG" /home/steam/.steam/steamcmd/7dtd/serverconfig.xml
# Set a Random Seed for the Random World Generator
  xmlstarlet edit --inplace \
    --update "//property[@name='WorldGenSeed']/@value" \
    --value "1354778" /home/steam/.steam/steamcmd/7dtd/serverconfig.xml
# Set the map size for the Random World Generator
# Has to be between 2048 and 16384
  xmlstarlet edit --inplace \
    --update "//property[@name='WorldGenSize']/@value" \
    --value "2048" /home/steam/.steam/steamcmd/7dtd/serverconfig.xml
# Set the Map Name for the Random World Generator
  xmlstarlet edit --inplace \
    --update "//property[@name='GameName']/@value" \
    --value "VaidoWorld" /home/steam/.steam/steamcmd/7dtd/serverconfig.xml
# Enable Control Panel for Direct Control of the GameServer
  xmlstarlet edit --inplace \
    --update "//property[@name='ControlPanelEnabled']/@value" \
    --value "true" /home/steam/.steam/steamcmd/7dtd/serverconfig.xml
EOF




# Change Default Game Save Folder for the Server (serveradmin.xml file is inside Game Save Folder, so it also changes its path altogether)
su --preserve-env "steam" <<- 'EOF'
SAVEGAME_FOLDER_PROPERTY="$(xmlstarlet sel -t -v \
'//property[@name="SaveGameFolder"]/@name' -n /home/steam/.steam/steamcmd/7dtd/serverconfig.xml)"
# Finds AdminFileName Property in the serverconfig.xml file and inserts SaveGameFolder that is relative to the Server Folder
# By default 7 Days To Die Game Save Folder and therefore AdminFile folder is outside the sever launch and configurations folder
# This script will force to store GameSaves and AdminFile in the 7DaysToDie server folder relatively.
[ "$SAVEGAME_FOLDER_PROPERTY" = "" ] && ( 
xmlstarlet ed --inplace -i "/ServerSettings/property[@name='AdminFileName']" -t elem -n newelement -v "" \
		   -i /ServerSettings/newelement -t attr -n name -v "SaveGameFolder" \
		   -i /ServerSettings/newelement -t attr -n value -v "./Saves" \
           --rename /ServerSettings/newelement \
           --value 'property' \
		   /home/steam/.steam/steamcmd/7dtd/serverconfig.xml
) || (
xmlstarlet --inplace edit \
  --update "//property[@name='SaveGameFolder']/@value" \
  --value "./Saves" /home/steam/.steam/steamcmd/7dtd/serverconfig.xml
)
EOF

# Launch server to generate the 7 Days To Die Game Map and serveradmin.xml
su --preserve-env "steam" <<- 'EOF'
    cd "/home/steam"
    HOME="/home/steam"
    cp "/home/steam/.steam/steamcmd/7dtd/serverconfig.xml" "/home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml"
    	xmlstarlet edit --inplace \
    		--update "//property[@name='ControlPanelEnabled']/@value" \
    		--value "true" /home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml
    	xmlstarlet edit --inplace \
    		--update "//property[@name='ControlPanelPassword']/@value" \
    		--value "hahaha" /home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml
    	xmlstarlet edit --inplace \
    		--update "//property[@name='TelnetEnabled']/@value" \
    		--value "true" /home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml
    	xmlstarlet edit --inplace \
    		--update "//property[@name='TelnetPort']/@value" \
    		--value "8081" /home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml
    	xmlstarlet edit --inplace \
    		--update "//property[@name='TelnetPassword']/@value" \
    		--value "hahaha" /home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml
    	screen -d -m -S "7DaysToDie_GameServer" "/home/steam/.steam/steamcmd/7dtd/startserver.sh" "-configfile=secure_serverconfig.xml"
EOF


# Add Empty Mods folder for the 7 Days To Die Dedicated Server, if it does not exist
mkdir /home/steam/.steam/steamcmd/7dtd/Mods

# Add Administrators to the 7 Days To Die server by modifying serveradmin.xml file
xmlstarlet ed --inplace -s /adminTools/admins -t elem -n admin -v "" -i /adminTools/admins/admin -t attr -n steamID -v 76561198072601792 -i /adminTools/admins/admin -t attr -n permission_level -v 0 /home/steam/.steam/steamcmd/7dtd/Saves/serveradmin.xml

# Launch 7 Days to Die server to Test the Gameplay
su --preserve-env "steam" <<- 'EOF'
    cd "/home/steam"
    HOME="/home/steam"
    cp "/home/steam/.steam/steamcmd/7dtd/serverconfig.xml" "/home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml"
    	xmlstarlet edit --inplace \
    		--update "//property[@name='ControlPanelEnabled']/@value" \
    		--value "true" /home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml
    	xmlstarlet edit --inplace \
    		--update "//property[@name='ControlPanelPassword']/@value" \
    		--value "hahaha" /home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml
    	xmlstarlet edit --inplace \
    		--update "//property[@name='TelnetEnabled']/@value" \
    		--value "true" /home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml
    	xmlstarlet edit --inplace \
    		--update "//property[@name='TelnetPort']/@value" \
    		--value "8081" /home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml
    	xmlstarlet edit --inplace \
    		--update "//property[@name='TelnetPassword']/@value" \
    		--value "hahaha" /home/steam/.steam/steamcmd/7dtd/secure_serverconfig.xml
    	screen -d -m -S "7DaysToDie_GameServer" "/home/steam/.steam/steamcmd/7dtd/startserver.sh" "-configfile=secure_serverconfig.xml"
EOF

# If the map is uploaded using linux root user, there is a need to change ownership of files
# chown -R steam /home/steam/.steam/steamcmd/7dtd/Saves
